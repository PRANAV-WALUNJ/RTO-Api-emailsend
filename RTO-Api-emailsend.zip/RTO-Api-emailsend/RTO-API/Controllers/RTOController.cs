﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using RTO_API.Model;
using System.IO;
using RTO_API.Interface;
using Microsoft.AspNetCore.Http;

namespace RTO_API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]

    public class RTOController : ControllerBase
    {
       
        private readonly IExport _export;
        public static IWebHostEnvironment _webHostEnviroment;
        public RTOController(IWebHostEnvironment webHostEnviroment , IExport export)
        {
            _webHostEnviroment = webHostEnviroment;
            _export = export;
        } 

       

        [HttpPost("UploadFile")]
        public async Task<IActionResult> UploadFile([FromForm] IFormFile file)
        {
            try
            {
                if(file.Length > 0)
                {
                    string path = _webHostEnviroment.WebRootPath + "\\upload\\";
                    if(!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    using (FileStream fileStream = System.IO.File.Create(path + file.FileName))
                    {
                        file.CopyTo(fileStream);
                        fileStream.Flush();
                        return Ok(new { Result = " Upload Done." });
                    }
                }
                else
                {
                    return Ok(new { Result = "Failed." });
                }
            }
            catch(Exception ex)
            {
                return BadRequest(ex);
            }
        }



        [HttpPost("LL_ExportData")]
        public IActionResult ExportData([FromForm] LL_Userdata userdata)
        {
            var result = _export.LL_Export_Excel(userdata);
            return File(result,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "RTO-User-Excel.xlsx"
                        );
        }
        [HttpPost("DL_ExportData")]
        public IActionResult DL_ExportData([FromForm] DL_Userdata userdata)
        {
            var result = _export.DL_Export_Excel(userdata);
            return File(result,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "RTO-User-Excel.xlsx"
                        );
        }
        [HttpPost("VR_ExportData")]
        public IActionResult VR_ExportData([FromForm] VR_Userdata userdata)
        {
            var result = _export.VR_Export_Excel(userdata);
            return File(result,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "RTO-User-Excel.xlsx"
                        );
        }
    }
}
