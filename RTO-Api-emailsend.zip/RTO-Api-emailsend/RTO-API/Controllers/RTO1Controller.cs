﻿using Microsoft.AspNetCore.Mvc;
using RTO_API.Interface;
using RTO_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RTO_API.Controllers
{
    [ApiController]

    [Route("api/[controller]")]
    public class RTO1Controller : Controller
    {

        IEmailService _emailService = null;
        public RTO1Controller(IEmailService emailService)
        {
            _emailService = emailService;
        }

        [HttpPost]
        public bool SendEmail([FromForm] EmailData emailData)
        {
            return _emailService.LL_SendEmail(emailData);
        }
    }
}
