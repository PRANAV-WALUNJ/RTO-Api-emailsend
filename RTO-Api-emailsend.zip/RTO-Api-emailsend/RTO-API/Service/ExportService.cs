﻿using ClosedXML.Excel;
using RTO_API.Interface;
using RTO_API.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RTO_API.Service
{
    public class ExportService : IExport
    {
        readonly IEmailService _emailService;
        public ExportService(IEmailService emailService)
        {
            _emailService = emailService;
        }
        
        public byte[] LL_Export_Excel(LL_Userdata userdata)
        {
            var workingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "ExcelFiles/LL_File");
            var excelPath = Path.Combine(workingDirectory, "LL_RTO.xlsx");

            if (!File.Exists(excelPath))
            {
                var file = new FileStream(excelPath, FileMode.CreateNew, FileAccess.ReadWrite);
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("RTO");
                    var currentRow = 1;

                    
                    worksheet.Cell(currentRow, 1).Value = "Username";
                    worksheet.Cell(currentRow, 2).Value = "Mobile";
                    worksheet.Cell(currentRow, 3).Value = "Email";
                    worksheet.Cell(currentRow, 4).Value = "AdharNumber";
                    worksheet.Cell(currentRow, 5).Value = "DOB";
                    workbook.SaveAs(file, true);
                }
                file.Close();
            }

            using (var workbook = new XLWorkbook(excelPath))
            {
                var worksheet = workbook.Worksheets.First(w => w.Name == "RTO");
                var currentRow = worksheet.Rows().Count() + 1;

               
                worksheet.Cell(currentRow, 1).Value = userdata.Username;
                worksheet.Cell(currentRow, 2).Value = userdata.Mobile;
                worksheet.Cell(currentRow, 3).Value = userdata.Email;
                worksheet.Cell(currentRow, 4).Value = userdata.AdharNumber;
                worksheet.Cell(currentRow, 5).Value = userdata.DOB;

                workbook.Save();
            }

            _emailService.LL_SendEmail(new EmailData { EmailToId = userdata.Email,EmailSubject="Registartion Succesfull for Learning Licence",EmailBody="Your Application for LL is accepted for processing . Your Application Number is LL_1324467657"});
            return Download(excelPath);
        }

       

        public byte[] DL_Export_Excel(DL_Userdata userdata)
        {
            var workingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "ExcelFiles/LL_File");
            var excelPath = Path.Combine(workingDirectory, "LL_RTO.xlsx");

            if (!File.Exists(excelPath))
            {
                var file = new FileStream(excelPath, FileMode.CreateNew, FileAccess.ReadWrite);
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("RTO");
                    var currentRow = 1;

                   
                    worksheet.Cell(currentRow, 1).Value = "Username";
                    worksheet.Cell(currentRow, 2).Value = "Email";
                    worksheet.Cell(currentRow, 3).Value = "LL_RegistrationNumber";
                    workbook.SaveAs(file, true);
                }
                file.Close();
            }

            using (var workbook = new XLWorkbook(excelPath))
            {
                var worksheet = workbook.Worksheets.First(w => w.Name == "RTO");
                var currentRow = worksheet.Rows().Count() + 1;

               
                worksheet.Cell(currentRow, 2).Value = userdata.Username;
                worksheet.Cell(currentRow, 3).Value = userdata.Email;
                worksheet.Cell(currentRow, 4).Value = userdata.LL_RegistrationNumber;

                workbook.Save();
            }

            _emailService.LL_SendEmail(new EmailData { EmailToId = userdata.Email, EmailSubject = "Registartion Succesfull for Driving Licence", EmailBody = "Your Application for DL is accepted for processing . Your Application Number is DL_2487314239" });
            return Download(excelPath);
        }

        public byte[] VR_Export_Excel(VR_Userdata userdata)
        {
            var workingDirectory = Path.Combine(Directory.GetCurrentDirectory(), "ExcelFiles/VR_File");
            var excelPath = Path.Combine(workingDirectory, "VR_RTO.xlsx");

            if (!File.Exists(excelPath))
            {
                var file = new FileStream(excelPath, FileMode.CreateNew, FileAccess.ReadWrite);
                using (var workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("RTO");
                    var currentRow = 1;

                    
                    worksheet.Cell(currentRow, 1).Value = "Username";
                    worksheet.Cell(currentRow, 2).Value = "Email";
                    worksheet.Cell(currentRow, 3).Value = "AdharNumber";
                    worksheet.Cell(currentRow, 4).Value = "Vehical_engine_no";
                    workbook.SaveAs(file, true);
                }
                file.Close();
            }

            using (var workbook = new XLWorkbook(excelPath))
            {
                var worksheet = workbook.Worksheets.First(w => w.Name == "RTO");
                var currentRow = worksheet.Rows().Count() + 1;

               
                worksheet.Cell(currentRow, 1).Value = userdata.Username;
                worksheet.Cell(currentRow, 2).Value = userdata.Email;
                worksheet.Cell(currentRow, 3).Value = userdata.AdharNumber;
                worksheet.Cell(currentRow, 4).Value = userdata.Vehical_engine_no;

                workbook.Save();
            }

            _emailService.LL_SendEmail(new EmailData { EmailToId = userdata.Email, EmailSubject = "Vehical Registration", EmailBody = "Your Application for Vehical Registration is accepted for processing . Your Application Number is VR_56627485996" });
            return Download(excelPath);
        }

        public byte[] Download(string filePath)
        {
            var file = File.ReadAllBytes(filePath);
            return file;
        }
    }
}

