﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RTO_API.Model
{
    public class VR_Userdata
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string AdharNumber { get; set; }
        public string Vehical_engine_no { get; set; }
    }
}
