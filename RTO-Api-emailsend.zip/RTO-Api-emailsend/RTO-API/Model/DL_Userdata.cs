﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RTO_API.Model
{
    public class DL_Userdata
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string LL_RegistrationNumber { get; set; }
    }
}
