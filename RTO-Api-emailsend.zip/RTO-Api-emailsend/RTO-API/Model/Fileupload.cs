﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RTO_API.Model
{
    public class Fileupload
    {
        public IFormFile file { get; set; }
    }
}
