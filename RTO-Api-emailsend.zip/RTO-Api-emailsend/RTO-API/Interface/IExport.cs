﻿using RTO_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RTO_API.Interface
{
    public interface IExport
    {
        public byte[] LL_Export_Excel(LL_Userdata userdata);
        public byte[] DL_Export_Excel(DL_Userdata userdata);
        public byte[] VR_Export_Excel(VR_Userdata userdata);
        public byte[] Download(string filePath);
    }
}
