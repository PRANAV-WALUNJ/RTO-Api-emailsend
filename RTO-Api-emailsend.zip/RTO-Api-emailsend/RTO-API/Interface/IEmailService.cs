﻿using RTO_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RTO_API.Interface
{
    public interface IEmailService
    {
        bool LL_SendEmail(EmailData emailData);
        bool DL_SendEmail(EmailData emailData);
        bool VR_SendEmail(EmailData emailData);
    }
}
