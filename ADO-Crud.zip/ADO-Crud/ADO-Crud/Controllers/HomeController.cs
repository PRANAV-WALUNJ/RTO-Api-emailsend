﻿using ADO_Crud.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace ADO_Crud.Controllers
{
    public class HomeController : Controller
    {
        //string myconnection = "Data Source=(localdb)\\mssqllocaldb;Initial Catelog=ADO-Crud;integated security=true";
        string myconnection = "Data Source =(localdb)\\mssqllocaldb;Initial Catalog = ADO-Crud; Integrated Security = True";
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(User u)
        {
            SqlConnection MainConnection = new SqlConnection(myconnection);
            MainConnection.Open();
            string Mycommand = "insert into Userinfo (Username) values ('" + u.Username + "')";
            SqlCommand mycommand = new SqlCommand(Mycommand, MainConnection);
            mycommand.ExecuteNonQuery();
            MainConnection.Close();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
