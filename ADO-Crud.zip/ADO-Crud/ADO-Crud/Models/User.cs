﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADO_Crud.Models
{
    public class User
    {
        public String Username { get; set; }
    }
}
