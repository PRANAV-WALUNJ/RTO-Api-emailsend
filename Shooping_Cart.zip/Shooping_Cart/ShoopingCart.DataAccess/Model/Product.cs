﻿using ShoopingCart.DataAccess.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoopingCart.DataAccess
{
   public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public string Discription { get; set; }
        public string Productimage { get; set; }
        public ICollection<ProductCategory> Categories { get; set; }
    }
}
