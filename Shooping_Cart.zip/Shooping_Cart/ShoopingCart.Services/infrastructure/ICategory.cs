﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoopingCart.DataAccess;
using ShoopingCart.DataAccess.Model;

namespace ShoopingCart.Services.infrastructure
{
   public interface ICategory
    {
        List<Category> GetAllCategories();
        Category GetCategoryById(int Id);
        void InsertCategory(Category category);
        void UpdateCategory(Category category);
        void DeleteCategory(Category category);
        void save();
    }
}
