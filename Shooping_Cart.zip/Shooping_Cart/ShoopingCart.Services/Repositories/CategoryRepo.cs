﻿using ShoopingCart.DataAccess;
using ShoopingCart.Services.Data;
using ShoopingCart.Services.infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoopingCart.Services.Repositories
{
    public class CategoryRepo : ICategory
    {
        private readonly ApplicationDbContex _context;

        public CategoryRepo(ApplicationDbContex context)
        {
            _context = context;
        }

        public void DeleteCategory(Category category)
        {
            _context.Categories.Remove(category);
        }

        public List<Category> GetAllCategories()
        {
            return _context.Categories.ToList();
        }

        public Category GetCategoryById(int Id)
        {
            return _context.Categories.Where(x => x.Id == Id).FirstOrDefault();
        }

        public void InsertCategory(Category category)
        {
            _context.Categories.Add(category);
        }

        public void save()
        {
            _context.SaveCihanges();
        }

        public void UpdateCategory(Category category)
        {
            _context.Categories.Update(category);
        }
    }
}
