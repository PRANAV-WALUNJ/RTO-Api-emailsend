﻿using Microsoft.EntityFrameworkCore;
using ShoopingCart.DataAccess;
using ShoopingCart.Services.Data;
using ShoopingCart.Services.infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoopingCart.Services.Repositories
{
    public class ProductRepo : IProduct
    {
        private readonly ApplicationDbContex _context;

        public ProductRepo(ApplicationDbContex context)
        {
            _context = context;
        }
        public void DeleteProduct(Product product)
        {
            _context.Products.Remove(product);
        }

        public List<Product> GetAllProduct()
        {
            return _context.Products.ToList();
        }

        public Product GetProductById(int Id)
        {
            return _context.Products.Include(x => x.Categories).ThenInclude(y => y.Category).Where(a => a.Id == Id).FirstOrDefault();
        }

        public void InsertProduct(Product product)
        {
            _context.Products.Add(product);
        }

        public void save()
        {
            _context.SaveChanges();
        }

        public void UpdateProduct(Product product)
        {
            throw new NotImplementedException();
        }
    }
}
