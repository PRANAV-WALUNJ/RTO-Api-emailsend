﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoopingCart.Web.Models
{
    public class item
    {
        public int id { get; set; }
        public string name { get; set; }
        public string qauntity { get; set; }
        public string prize { get; set; }
    }
}
