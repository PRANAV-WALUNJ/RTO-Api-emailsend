﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoopingCart.DataAccess;
using ShoopingCart.Services.infrastructure;
using ShoopingCart.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoopingCart.Web.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly ICategory _category;
        private IMapper _mapper;
        public CategoriesController(ICategory category, IMapper mapper)
        {
            _category = category;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var AllCategories = _category.GetAllCategories();
            var mapperCategories = _mapper.Map<List<CategoryViewModel>>(AllCategories);


            return View(mapperCategories);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Details(int id)
        {
            var category = _category.GetCategoryById(id);
            var mappedCategory = _mapper.Map<DetailCategoryViewModel>(category);
            return View(mappedCategory);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var category = _category.GetCategoryById(id);
            var mappedCategory = _mapper.Map<EditCategoryViewModel>(category);
            return View(mappedCategory);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var category = _category.GetCategoryById(id);
            var mappedCategory = _mapper.Map<DeleteCategoryViewModel>(category);
            return View(mappedCategory);
        }


        [HttpPost]
        public IActionResult Delete(DeleteCategoryViewModel vm)
        {
            var mappedCategoryInModel = _mapper.Map<Category>(vm);
            _category.DeleteCategory(mappedCategoryInModel);
            _category.save();
            return RedirectToAction("Index", "Categories");

        }
        [HttpPost]
        public IActionResult Edit(EditCategoryViewModel vm)
        {
            var mappedCategoryInModel = _mapper.Map<Category>(vm);
            _category.UpdateCategory(mappedCategoryInModel);
            _category.save();
            return RedirectToAction("Index", "Categories");

        }
        [HttpPost]
        public IActionResult Create(CreateCategoryViewModel vm)
        {
            var mappedCategoryInModel = _mapper.Map<Category>(vm);
            _category.InsertCategory(mappedCategoryInModel);
            _category.save();
            return RedirectToAction("Index", "Categories");
        }

    }
}
