﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ShoopingCart.Services.infrastructure;
using ShoopingCart.Web.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShoopingCart.Web.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IProduct _product;
        private IMapper _mapper;

        public ProductsController(IProduct product,IMapper mapper)
        {
            _product = product;
            _mapper = mapper;
        }
        [HttpGet]
        public IActionResult Index()
        {
            var productList = _product.GetAllProduct();
            var mappedProducts = _mapper.Map<List<ProductViewModel>>(productList);
            return View(productList);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Edit()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Delete()
        {
            return View();
        }
    }
}
